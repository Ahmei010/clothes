# Images Directory

This directory contains all the image assets for Madam's Boutique website.

## Image Files Included

### Logo & Branding
- `logo.png.svg` - Main boutique logo

### Designer Collections
- `designer-1.svg` through `designer-6.svg` - Maria B, Sana Safinaz, Khaadi, Gul Ahmed, HSY, Sania Maskatiya

### Collections
- `collection-card-1.svg` through `collection-card-4.svg` - Featured collection cards
- `boutique-interior.svg` - Boutique interior image
- `hero-bg.svg` - Hero section background

### Attire Types
- `saree.svg` - Saree collection
- `lehenga.svg` - Lehenga collection
- `salwar-suit.svg` - Salwar suit collection
- `western-wear.svg` - Western wear collection
- `ethnic-wear.svg` - Ethnic wear collection
- `party-wear.svg` - Party wear collection
- `casual-wear.svg` - Casual wear collection
- `wedding-collection.svg` - Wedding collection

### Accessories
- `jewelry.svg` - Jewelry collection
- `handbags.svg` - Handbags collection
- `footwear.svg` - Footwear collection
- `scarves.svg` - Scarves and dupattas
- `belts.svg` - Belts collection
- `watches.svg` - Watches collection

### Fabrics (Unstitched)
- `cotton-fabric.svg` - Cotton fabrics
- `silk-fabric.svg` - Silk fabrics
- `georgette-fabric.svg` - Georgette fabrics
- `chiffon-fabric.svg` - Chiffon fabrics
- `linen-fabric.svg` - Linen fabrics
- `embroidered-fabric.svg` - Embroidered fabrics

### Gallery Images
- `gallery-bridal-1.svg` through `gallery-bridal-3.svg` - Bridal collection gallery
- `gallery-party-1.svg` through `gallery-party-3.svg` - Party wear gallery
- `gallery-casual-1.svg` through `gallery-casual-3.svg` - Casual wear gallery
- `gallery-traditional-1.svg` through `gallery-traditional-3.svg` - Traditional wear gallery

### Brand Logos
- `brand-maria-b.svg` - Maria B brand logo
- `brand-sana-safinaz.svg` - Sana Safinaz brand logo
- `brand-khaadi.svg` - Khaadi brand logo
- `brand-gul-ahmed.svg` - Gul Ahmed brand logo
- `brand-hsy.svg` - HSY brand logo
- `brand-sania.svg` - Sania Maskatiya brand logo

### Services
- `service-designers.svg` - Designer services
- `service-attire.svg` - Attire services
- `service-accessories.svg` - Accessories services
- `service-unstitched.svg` - Unstitched garments services

### About Page
- `about-boutique.svg` - About page main image

## Note

All images are currently in SVG format as placeholders. These are lightweight vector graphics that will display correctly in all modern browsers.

### Replacing with Actual Images

If you want to replace these placeholder images with actual photographs:

1. **Recommended formats**: JPG, PNG, or WebP
2. **Recommended sizes**:
   - Logo: 200x80px (or 2x for retina displays: 400x160px)
   - Product/Designer images: 400x500px minimum
   - Gallery images: 500x600px minimum
   - Collection cards: 300x400px
   - Brand logos: 60x60px (circular)

3. **Maintain the same file names** (but change extension from .svg to .jpg/.png) so the HTML references work correctly

4. **Optimize images** for web:
   - Compress images to reduce file size
   - Use appropriate quality settings
   - Consider using WebP format for better compression

5. **All images must have proper alt attributes** (already included in HTML)

## Color Scheme

The placeholder images use the boutique's color scheme:
- Primary: #e8b4c9, #d4a5c7, #c096b5
- Secondary: #af87a3, #9f7a93, #8f6a83

